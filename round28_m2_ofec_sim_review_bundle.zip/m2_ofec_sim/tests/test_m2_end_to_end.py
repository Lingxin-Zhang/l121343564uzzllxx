from m2_ofec_sim.sim import run_paired_sweep


def test_tiny_m2_reference_and_lut_curves_match(tmp_path):
    result = run_paired_sweep(
        snr_values=[13.9],
        h=1,
        min_post_errors=1,
        max_blocks=1,
        batch_blocks=1,
        seed=123,
        block_width=14,
        output_dir=tmp_path,
        time_budget_s=120.0,
    )

    assert result.diff_rows
    assert all(row["matched"] for row in result.diff_rows)
    assert result.reference_rows[0]["post_errors"] == result.block_lut_rows[0]["post_errors"]
    assert result.reference_rows[0]["post_ber"] == result.block_lut_rows[0]["post_ber"]
