This directory is an independent minimal end-to-end simulator for Round 28.
It consumes the GF(2) kernels from the sibling `fec_linear_backend` repository
but is intentionally not part of that kernel repository.

Keep the simulator reproducible and small:
- Do not reimplement the GF(2) kernels.
- Share component-code error-location logic between compared backends.
- Write raw CSV outputs for every run; do not hand-enter figure or summary
  numbers.
- Prefer short smoke tests over long BER sweeps in CI-style verification.
