"""Small 16-QAM AWGN hard-decision channel used by the M2 smoke simulator."""

from __future__ import annotations

import numpy as np

_LEVELS = np.array([-3.0, -1.0, 1.0, 3.0], dtype=np.float64) / np.sqrt(10.0)
_PAIR_TO_INDEX = np.array([0, 1, 3, 2], dtype=np.int8)
_INDEX_TO_PAIR = np.array([[0, 0], [0, 1], [1, 1], [1, 0]], dtype=np.uint8)


def transmit_16qam_hard(bits: np.ndarray, snr_db: float, rng: np.random.Generator) -> np.ndarray:
    """Transmit GF(2) bits through normalized 16-QAM AWGN and hard demodulate."""
    flat = np.asarray(bits, dtype=np.uint8).reshape(-1) & 1
    original_len = flat.size
    pad = (-original_len) % 4
    if pad:
        flat = np.concatenate([flat, np.zeros(pad, dtype=np.uint8)])

    groups = flat.reshape(-1, 4)
    i_index = _PAIR_TO_INDEX[(groups[:, 0] << 1) | groups[:, 1]]
    q_index = _PAIR_TO_INDEX[(groups[:, 2] << 1) | groups[:, 3]]
    symbols = _LEVELS[i_index] + 1j * _LEVELS[q_index]

    snr_linear = 10.0 ** (float(snr_db) / 10.0)
    sigma = np.sqrt(1.0 / (2.0 * snr_linear))
    noise = rng.normal(0.0, sigma, size=symbols.shape) + 1j * rng.normal(
        0.0, sigma, size=symbols.shape
    )
    received = symbols + noise

    hard_i = np.digitize(received.real, [-2.0 / np.sqrt(10.0), 0.0, 2.0 / np.sqrt(10.0)])
    hard_q = np.digitize(received.imag, [-2.0 / np.sqrt(10.0), 0.0, 2.0 / np.sqrt(10.0)])
    out = np.empty((groups.shape[0], 4), dtype=np.uint8)
    out[:, 0:2] = _INDEX_TO_PAIR[hard_i]
    out[:, 2:4] = _INDEX_TO_PAIR[hard_q]
    return out.reshape(-1)[:original_len].reshape(np.asarray(bits).shape)
