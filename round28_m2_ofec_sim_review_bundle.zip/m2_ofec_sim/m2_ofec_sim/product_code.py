"""Minimal BCH(255,239) product-code encoder and iterative BDD decoder."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .paths import ensure_fec_backend_on_path

ensure_fec_backend_on_path()

from codes.bch_like import make_bch255_t2_syndrome_matrix_galois_systematic
from decoders.bdd_lut import BDDLUTDecoder
from linear_kernel import PackedBatchGF2Kernel, PackedBlockLUTKernel


@dataclass(frozen=True)
class ComponentCode:
    """Systematic BCH component matrix and shared BDD locator."""

    matrix: np.ndarray
    k: int
    n: int
    parity_kernel: PackedBatchGF2Kernel
    decoder: BDDLUTDecoder

    @property
    def r(self) -> int:
        return self.n - self.k


def build_bch255_component() -> ComponentCode:
    """Build BCH(255,239) H^T=[P;I] once for M2."""
    matrix = make_bch255_t2_syndrome_matrix_galois_systematic()
    k = 239
    n = 255
    return ComponentCode(
        matrix=matrix,
        k=k,
        n=n,
        parity_kernel=PackedBatchGF2Kernel(matrix[:k]),
        decoder=BDDLUTDecoder(matrix, t=2, strict_collision_check=True),
    )


def make_syndrome_backend(component: ComponentCode, kind: str, block_width: int) -> Any:
    """Create the selectable syndrome backend; locator logic is shared."""
    if kind == "reference":
        return PackedBatchGF2Kernel(component.matrix)
    if kind == "block_lut":
        return PackedBlockLUTKernel(component.matrix, block_width=block_width, packed_word_bits=16)
    raise ValueError(f"unknown backend kind: {kind}")


def encode_product_code(info: np.ndarray, component: ComponentCode) -> np.ndarray:
    """Encode a k x k payload into an n x n systematic product-code block."""
    info = np.asarray(info, dtype=np.uint8) & 1
    if info.shape != (component.k, component.k):
        raise ValueError(f"info must have shape {(component.k, component.k)}")

    row_parity = component.parity_kernel.apply_many(info)
    top = np.concatenate([info, row_parity], axis=1)
    column_parity = component.parity_kernel.apply_many(top.T).T
    return np.concatenate([top, column_parity], axis=0).astype(np.uint8, copy=False)


def decode_product_code(
    received: np.ndarray,
    component: ComponentCode,
    syndrome_backend: Any,
    *,
    h: int,
) -> tuple[np.ndarray, dict[str, int]]:
    """Run h row/column BDD sweeps with a supplied syndrome backend."""
    word = (np.asarray(received, dtype=np.uint8) & 1).copy()
    if word.shape != (component.n, component.n):
        raise ValueError(f"received must have shape {(component.n, component.n)}")

    counters = {
        "row_failures": 0,
        "column_failures": 0,
        "row_corrected": 0,
        "column_corrected": 0,
    }
    for _ in range(int(h)):
        row_result = component.decoder.decode_words(word, syndrome_backend=syndrome_backend)
        word = row_result["corrected_words"]
        counters["row_failures"] += int(np.count_nonzero(row_result["statuses"] == "failure"))
        counters["row_corrected"] += int(np.count_nonzero(row_result["statuses"] == "corrected"))

        column_result = component.decoder.decode_words(word.T, syndrome_backend=syndrome_backend)
        word = column_result["corrected_words"].T
        counters["column_failures"] += int(np.count_nonzero(column_result["statuses"] == "failure"))
        counters["column_corrected"] += int(np.count_nonzero(column_result["statuses"] == "corrected"))
    return word.astype(np.uint8, copy=False), counters


def random_product_codeword(rng: np.random.Generator, component: ComponentCode) -> tuple[np.ndarray, np.ndarray]:
    """Return payload and encoded product-code block."""
    info = rng.integers(0, 2, size=(component.k, component.k), dtype=np.uint8)
    return info, encode_product_code(info, component)
