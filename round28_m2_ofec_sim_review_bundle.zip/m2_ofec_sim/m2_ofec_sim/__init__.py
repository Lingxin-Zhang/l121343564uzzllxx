"""Minimal product-code/OFEC-style BER simulator for Round 28."""

from .sim import PairedSweepResult, run_paired_sweep

__all__ = ["PairedSweepResult", "run_paired_sweep"]
