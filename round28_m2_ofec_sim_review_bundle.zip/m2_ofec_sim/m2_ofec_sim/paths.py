"""Path helpers for importing the sibling GF(2) kernel repository."""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ACP_ROOT = ROOT.parent
FEC_BACKEND_ROOT = ACP_ROOT / "fec_linear_backend"


def ensure_fec_backend_on_path() -> Path:
    """Make the sibling fec_linear_backend repository importable."""
    path = str(FEC_BACKEND_ROOT)
    if path not in sys.path:
        sys.path.insert(0, path)
    return FEC_BACKEND_ROOT
