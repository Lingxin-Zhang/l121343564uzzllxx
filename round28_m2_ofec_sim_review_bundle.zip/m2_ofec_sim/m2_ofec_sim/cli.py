"""CLI for the M2 paired BER sweep."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .sim import run_paired_sweep


def _snr_values(args: argparse.Namespace) -> list[float]:
    values = []
    current = float(args.snr_min)
    while current <= float(args.snr_max) + 1e-12:
        values.append(round(current, 10))
        current += float(args.snr_step)
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description="Run M2 product-code paired BER sweep.")
    parser.add_argument("--snr-min", type=float, default=13.7)
    parser.add_argument("--snr-max", type=float, default=14.2)
    parser.add_argument("--snr-step", type=float, default=0.1)
    parser.add_argument("--h", type=int, default=10)
    parser.add_argument("--min-post-errors", type=int, default=100)
    parser.add_argument("--max-blocks", type=int, default=30_000)
    parser.add_argument("--batch-blocks", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--block-width", type=int, default=14)
    parser.add_argument("--time-budget-s", type=float, default=1800.0)
    parser.add_argument("--output-dir", type=Path, default=Path("results/raw"))
    args = parser.parse_args()

    result = run_paired_sweep(
        snr_values=_snr_values(args),
        h=args.h,
        min_post_errors=args.min_post_errors,
        max_blocks=args.max_blocks,
        batch_blocks=args.batch_blocks,
        seed=args.seed,
        block_width=args.block_width,
        output_dir=args.output_dir,
        time_budget_s=args.time_budget_s,
    )
    matched = all(row["matched"] for row in result.diff_rows)
    ref_total = sum(float(row["elapsed_s"]) for row in result.reference_rows)
    lut_total = sum(float(row["elapsed_s"]) for row in result.block_lut_rows)
    ratio = (ref_total / lut_total) if lut_total > 0 else np.nan
    print(f"points={len(result.diff_rows)} matched={matched} reference_over_block_lut={ratio:.6g}")
    print(f"output_dir={result.output_dir}")
    return 0 if matched else 2


if __name__ == "__main__":
    raise SystemExit(main())
