"""Reproducible paired BER sweep for the M2 product-code simulator."""

from __future__ import annotations

import csv
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from .channel import transmit_16qam_hard
from .product_code import (
    build_bch255_component,
    decode_product_code,
    make_syndrome_backend,
    random_product_codeword,
)


@dataclass
class PairedSweepResult:
    reference_rows: list[dict[str, Any]]
    block_lut_rows: list[dict[str, Any]]
    diff_rows: list[dict[str, Any]]
    timing_rows: list[dict[str, Any]]
    output_dir: Path


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _simulate_point(
    *,
    component: Any,
    backend: Any,
    snr_db: float,
    backend_kind: str,
    h: int,
    min_post_errors: int,
    max_blocks: int,
    batch_blocks: int,
    seed: int,
    block_width: int,
    build_init_s: float,
) -> dict[str, Any]:
    rng = np.random.default_rng(int(seed))
    start = time.perf_counter()
    blocks = 0
    pre_errors = 0
    post_errors = 0
    total_bits = 0
    row_failures = 0
    column_failures = 0
    row_corrected = 0
    column_corrected = 0

    while blocks < int(max_blocks) and post_errors < int(min_post_errors):
        chunk = min(int(batch_blocks), int(max_blocks) - blocks)
        for _ in range(chunk):
            _, codeword = random_product_codeword(rng, component)
            received = transmit_16qam_hard(codeword, snr_db, rng)
            decoded, counters = decode_product_code(received, component, backend, h=h)
            pre_errors += int(np.count_nonzero(received ^ codeword))
            post_errors += int(np.count_nonzero(decoded ^ codeword))
            total_bits += int(codeword.size)
            row_failures += counters["row_failures"]
            column_failures += counters["column_failures"]
            row_corrected += counters["row_corrected"]
            column_corrected += counters["column_corrected"]
            blocks += 1
            if blocks >= int(max_blocks) or post_errors >= int(min_post_errors):
                break

    online_elapsed_s = time.perf_counter() - start
    stop_reason = "min_post_errors" if post_errors >= int(min_post_errors) else "max_blocks"
    return {
        "backend": backend_kind,
        "snr_db": float(snr_db),
        "h": int(h),
        "min_post_errors": int(min_post_errors),
        "max_blocks": int(max_blocks),
        "batch_blocks": int(batch_blocks),
        "seed": int(seed),
        "block_width": int(block_width) if backend_kind == "block_lut" else "",
        "blocks": int(blocks),
        "total_bits": int(total_bits),
        "pre_errors": int(pre_errors),
        "post_errors": int(post_errors),
        "pre_ber": (pre_errors / total_bits) if total_bits else 0.0,
        "post_ber": (post_errors / total_bits) if total_bits else 0.0,
        "row_failures": int(row_failures),
        "column_failures": int(column_failures),
        "row_corrected": int(row_corrected),
        "column_corrected": int(column_corrected),
        "build_init_s": build_init_s,
        "online_elapsed_s": online_elapsed_s,
        "elapsed_s": build_init_s + online_elapsed_s,
        "stop_reason": stop_reason,
        "component": "bch_255_239_product_code",
        "channel": "16qam_awgn_hard",
    }


def _diff_rows(reference_rows: list[dict[str, Any]], block_lut_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_snr = {float(row["snr_db"]): row for row in block_lut_rows}
    rows: list[dict[str, Any]] = []
    for ref in reference_rows:
        snr = float(ref["snr_db"])
        lut = by_snr[snr]
        post_ber_delta = float(lut["post_ber"]) - float(ref["post_ber"])
        pre_ber_delta = float(lut["pre_ber"]) - float(ref["pre_ber"])
        matched = (
            int(ref["blocks"]) == int(lut["blocks"])
            and int(ref["total_bits"]) == int(lut["total_bits"])
            and int(ref["pre_errors"]) == int(lut["pre_errors"])
            and int(ref["post_errors"]) == int(lut["post_errors"])
            and post_ber_delta == 0.0
            and pre_ber_delta == 0.0
        )
        rows.append(
            {
                "snr_db": snr,
                "matched": bool(matched),
                "blocks_delta": int(lut["blocks"]) - int(ref["blocks"]),
                "total_bits_delta": int(lut["total_bits"]) - int(ref["total_bits"]),
                "pre_errors_delta": int(lut["pre_errors"]) - int(ref["pre_errors"]),
                "post_errors_delta": int(lut["post_errors"]) - int(ref["post_errors"]),
                "pre_ber_delta": pre_ber_delta,
                "post_ber_delta": post_ber_delta,
            }
        )
    return rows


def _timing_rows(reference_rows: list[dict[str, Any]], block_lut_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for backend, backend_rows in (("reference", reference_rows), ("block_lut", block_lut_rows)):
        rows.append(
            {
                "backend": backend,
                "points": len(backend_rows),
                "total_build_init_s": sum(float(row["build_init_s"]) for row in backend_rows),
                "total_online_elapsed_s": sum(float(row["online_elapsed_s"]) for row in backend_rows),
                "total_elapsed_s": sum(float(row["elapsed_s"]) for row in backend_rows),
            }
        )
    if reference_rows and block_lut_rows:
        ref_total = sum(float(row["elapsed_s"]) for row in reference_rows)
        lut_total = sum(float(row["elapsed_s"]) for row in block_lut_rows)
        rows.append(
            {
                "backend": "ratio_reference_over_block_lut",
                "points": len(reference_rows),
                "total_build_init_s": "",
                "total_online_elapsed_s": "",
                "total_elapsed_s": (ref_total / lut_total) if lut_total > 0 else 0.0,
            }
        )
    return rows


def run_paired_sweep(
    *,
    snr_values: Iterable[float],
    h: int,
    min_post_errors: int,
    max_blocks: int,
    batch_blocks: int,
    seed: int,
    block_width: int,
    output_dir: str | Path,
    time_budget_s: float,
) -> PairedSweepResult:
    """Run reference and block-LUT backends on the same SNR/seed stream."""
    output_dir = Path(output_dir)
    reference_rows: list[dict[str, Any]] = []
    block_lut_rows: list[dict[str, Any]] = []
    init_start = time.perf_counter()
    component = build_bch255_component()
    component_build_s = time.perf_counter() - init_start
    ref_backend_start = time.perf_counter()
    reference_backend = make_syndrome_backend(component, "reference", block_width)
    reference_backend_build_s = time.perf_counter() - ref_backend_start
    lut_backend_start = time.perf_counter()
    block_lut_backend = make_syndrome_backend(component, "block_lut", block_width)
    block_lut_backend_build_s = time.perf_counter() - lut_backend_start
    sweep_start = time.perf_counter()

    for index, snr in enumerate(list(snr_values)):
        point_seed = int(seed) + index
        ref = _simulate_point(
            component=component,
            backend=reference_backend,
            snr_db=float(snr),
            backend_kind="reference",
            h=h,
            min_post_errors=min_post_errors,
            max_blocks=max_blocks,
            batch_blocks=batch_blocks,
            seed=point_seed,
            block_width=block_width,
            build_init_s=component_build_s + reference_backend_build_s if index == 0 else 0.0,
        )
        lut = _simulate_point(
            component=component,
            backend=block_lut_backend,
            snr_db=float(snr),
            backend_kind="block_lut",
            h=h,
            min_post_errors=min_post_errors,
            max_blocks=max_blocks,
            batch_blocks=batch_blocks,
            seed=point_seed,
            block_width=block_width,
            build_init_s=component_build_s + block_lut_backend_build_s if index == 0 else 0.0,
        )
        reference_rows.append(ref)
        block_lut_rows.append(lut)
        if time.perf_counter() - sweep_start >= float(time_budget_s):
            break

    diff_rows = _diff_rows(reference_rows, block_lut_rows)
    timing_rows = _timing_rows(reference_rows, block_lut_rows)
    _write_csv(output_dir / "m2_reference_ber.csv", reference_rows)
    _write_csv(output_dir / "m2_block_lut_ber.csv", block_lut_rows)
    _write_csv(output_dir / "m2_curve_diff.csv", diff_rows)
    _write_csv(output_dir / "m2_timing.csv", timing_rows)
    return PairedSweepResult(reference_rows, block_lut_rows, diff_rows, timing_rows, output_dir)
