from __future__ import annotations

"""Thin paired runner around the real local OFEC simulator."""

import argparse
import csv
import importlib.util
import sys
import time
from pathlib import Path
from typing import Any, Iterable

from .backend import BlockLUTBCHBackend

ACP_ROOT = Path(__file__).resolve().parents[2]
OFEC_ROOT = Path(r"D:\PKU\OFEC\project\ofec-0.1.0")
BASELINE_SCRIPT = OFEC_ROOT / "scripts" / "reproduce_fig3_baseline.py"


def _ensure_ofec_on_path() -> None:
    path_text = str(OFEC_ROOT)
    if path_text not in sys.path:
        sys.path.insert(0, path_text)


def _load_baseline_module():
    _ensure_ofec_on_path()
    spec = importlib.util.spec_from_file_location("ofec_reproduce_fig3_baseline", BASELINE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load OFEC baseline script from {BASELINE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _snr_values(snr_min: float, snr_max: float, snr_step: float) -> list[float]:
    values = []
    current = float(snr_min)
    while current <= float(snr_max) + 1e-12:
        values.append(round(current, 10))
        current += float(snr_step)
    return values


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _run_one_point(
    *,
    baseline,
    backend_label: str,
    backend_arg: str | BlockLUTBCHBackend,
    snr_db: float,
    h: int,
    min_post_errors: int,
    max_blocks: int,
    batch_blocks: int,
    seed: int,
    target_post_ber: float,
    codec_mode: str,
    block_width: int | str,
    external_backend_init_sec: float,
    common_table_init_sec: float,
) -> dict[str, Any]:
    wall_start = time.perf_counter()
    row = baseline.simulate_snr_point(
        snr_db=snr_db,
        batch_blocks=batch_blocks,
        max_blocks=max_blocks,
        min_post_errors=min_post_errors,
        target_post_ber=target_post_ber,
        h=h,
        seed=seed,
        device="cpu",
        bch_backend=backend_arg,
        codec_mode=codec_mode,
        parallel_mode="serial",
        workers=1,
        device_pool="",
        mc_warmup_blocks=0,
        mc_measure_blocks=0,
        mc_discard_flush=True,
        progress_callback=None,
        point_progress=None,
        checkpoint_interval_batches=8,
    )
    out = dict(row)
    out["backend"] = backend_label
    out["block_width"] = block_width
    out["external_backend_init_sec"] = float(external_backend_init_sec)
    out["common_table_init_sec"] = float(common_table_init_sec)
    out["point_wall_sec"] = float(external_backend_init_sec) + (time.perf_counter() - wall_start)
    return out


def _paired_diff(reference_rows: list[dict[str, Any]], block_lut_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_snr = {float(row["snr_db"]): row for row in block_lut_rows}
    rows: list[dict[str, Any]] = []
    for ref in reference_rows:
        snr = float(ref["snr_db"])
        lut = by_snr[snr]
        pre_delta = int(lut["pre_fec_errors"]) - int(ref["pre_fec_errors"])
        post_delta = int(lut["post_fec_errors"]) - int(ref["post_fec_errors"])
        pre_ber_delta = float(lut["pre_fec_ber"]) - float(ref["pre_fec_ber"])
        post_ber_delta = float(lut["post_fec_ber"]) - float(ref["post_fec_ber"])
        matched = (
            int(lut["total_blocks"]) == int(ref["total_blocks"])
            and int(lut["emitted_blocks"]) == int(ref["emitted_blocks"])
            and int(lut["total_bits"]) == int(ref["total_bits"])
            and pre_delta == 0
            and post_delta == 0
            and pre_ber_delta == 0.0
            and post_ber_delta == 0.0
        )
        rows.append(
            {
                "snr_db": snr,
                "matched": bool(matched),
                "total_blocks_delta": int(lut["total_blocks"]) - int(ref["total_blocks"]),
                "emitted_blocks_delta": int(lut["emitted_blocks"]) - int(ref["emitted_blocks"]),
                "total_bits_delta": int(lut["total_bits"]) - int(ref["total_bits"]),
                "pre_fec_errors_delta": pre_delta,
                "post_fec_errors_delta": post_delta,
                "pre_fec_ber_delta": pre_ber_delta,
                "post_fec_ber_delta": post_ber_delta,
            }
        )
    return rows


def _timing_rows(reference_rows: list[dict[str, Any]], block_lut_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for backend, backend_rows in (
        ("syndrome_lut", reference_rows),
        ("block_lut", block_lut_rows),
    ):
        rows.append(
            {
                "backend": backend,
                "points": len(backend_rows),
                "total_common_table_init_sec": sum(float(row["common_table_init_sec"]) for row in backend_rows),
                "total_external_backend_init_sec": sum(float(row["external_backend_init_sec"]) for row in backend_rows),
                "total_point_wall_sec": sum(float(row["point_wall_sec"]) for row in backend_rows),
                "total_wall_with_common_init_sec": (
                    sum(float(row["common_table_init_sec"]) for row in backend_rows)
                    + sum(float(row["point_wall_sec"]) for row in backend_rows)
                ),
                "total_elapsed_sec": sum(float(row["elapsed_sec"]) for row in backend_rows),
                "total_codec_init_sec": sum(float(row["codec_init_sec"]) for row in backend_rows),
                "total_decode_sec": sum(float(row["decode_sec"]) for row in backend_rows),
                "total_blocks": sum(int(row["total_blocks"]) for row in backend_rows),
                "total_emitted_blocks": sum(int(row["emitted_blocks"]) for row in backend_rows),
            }
        )
    if reference_rows and block_lut_rows:
        ref_wall = sum(float(row["point_wall_sec"]) for row in reference_rows)
        lut_wall = sum(float(row["point_wall_sec"]) for row in block_lut_rows)
        ref_wall_with_common = ref_wall + sum(float(row["common_table_init_sec"]) for row in reference_rows)
        lut_wall_with_common = lut_wall + sum(float(row["common_table_init_sec"]) for row in block_lut_rows)
        ref_decode = sum(float(row["decode_sec"]) for row in reference_rows)
        lut_decode = sum(float(row["decode_sec"]) for row in block_lut_rows)
        rows.append(
            {
                "backend": "ratio_syndrome_lut_over_block_lut",
                "points": len(reference_rows),
                "total_common_table_init_sec": "",
                "total_external_backend_init_sec": "",
                "total_point_wall_sec": (ref_wall / lut_wall) if lut_wall > 0 else 0.0,
                "total_wall_with_common_init_sec": (
                    ref_wall_with_common / lut_wall_with_common
                )
                if lut_wall_with_common > 0
                else 0.0,
                "total_elapsed_sec": "",
                "total_codec_init_sec": "",
                "total_decode_sec": (ref_decode / lut_decode) if lut_decode > 0 else 0.0,
                "total_blocks": "",
                "total_emitted_blocks": "",
            }
        )
    return rows


def run_paired_sweep(
    *,
    snr_values: Iterable[float],
    h: int,
    min_post_errors: int,
    max_blocks: int,
    batch_blocks: int,
    seed: int,
    block_width: int,
    target_post_ber: float,
    codec_mode: str,
    time_budget_s: float,
    output_dir: str | Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    baseline = _load_baseline_module()
    from ofec.codec._ebch_lut import build_syndrome_lut_tables

    common_init_start = time.perf_counter()
    build_syndrome_lut_tables(255, 239)
    common_table_init_sec = time.perf_counter() - common_init_start
    output_dir = Path(output_dir)
    reference_rows: list[dict[str, Any]] = []
    block_lut_rows: list[dict[str, Any]] = []
    sweep_start = time.perf_counter()

    for idx, snr_db in enumerate(list(snr_values)):
        point_seed = int(seed) + idx
        reference_rows.append(
            _run_one_point(
                baseline=baseline,
                backend_label="syndrome_lut",
                backend_arg="syndrome_lut",
                snr_db=float(snr_db),
                h=h,
                min_post_errors=min_post_errors,
                max_blocks=max_blocks,
                batch_blocks=batch_blocks,
                seed=point_seed,
                target_post_ber=target_post_ber,
                codec_mode=codec_mode,
                block_width="",
                external_backend_init_sec=0.0,
                common_table_init_sec=common_table_init_sec if idx == 0 else 0.0,
            )
        )
        backend_init_start = time.perf_counter()
        block_lut_backend = BlockLUTBCHBackend(255, 239, block_width=block_width)
        backend_init_sec = time.perf_counter() - backend_init_start
        block_lut_rows.append(
            _run_one_point(
                baseline=baseline,
                backend_label="block_lut",
                backend_arg=block_lut_backend,
                snr_db=float(snr_db),
                h=h,
                min_post_errors=min_post_errors,
                max_blocks=max_blocks,
                batch_blocks=batch_blocks,
                seed=point_seed,
                target_post_ber=target_post_ber,
                codec_mode=codec_mode,
                block_width=block_width,
                external_backend_init_sec=backend_init_sec,
                common_table_init_sec=common_table_init_sec if idx == 0 else 0.0,
            )
        )
        diff_rows = _paired_diff(reference_rows, block_lut_rows)
        timing_rows = _timing_rows(reference_rows, block_lut_rows)
        _write_csv(output_dir / "real_ofec_syndrome_lut_ber.csv", reference_rows)
        _write_csv(output_dir / "real_ofec_block_lut_ber.csv", block_lut_rows)
        _write_csv(output_dir / "real_ofec_curve_diff.csv", diff_rows)
        _write_csv(output_dir / "real_ofec_timing.csv", timing_rows)
        if time.perf_counter() - sweep_start >= float(time_budget_s):
            break

    diff_rows = _paired_diff(reference_rows, block_lut_rows)
    timing_rows = _timing_rows(reference_rows, block_lut_rows)
    _write_csv(output_dir / "real_ofec_syndrome_lut_ber.csv", reference_rows)
    _write_csv(output_dir / "real_ofec_block_lut_ber.csv", block_lut_rows)
    _write_csv(output_dir / "real_ofec_curve_diff.csv", diff_rows)
    _write_csv(output_dir / "real_ofec_timing.csv", timing_rows)
    return reference_rows, block_lut_rows, diff_rows, timing_rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Run real OFEC paired backend BER sweep.")
    parser.add_argument("--snr-min", type=float, default=13.7)
    parser.add_argument("--snr-max", type=float, default=14.2)
    parser.add_argument("--snr-step", type=float, default=0.1)
    parser.add_argument("--h", type=int, default=10)
    parser.add_argument("--min-post-errors", type=int, default=100)
    parser.add_argument("--max-blocks", type=int, default=160)
    parser.add_argument("--batch-blocks", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--block-width", type=int, default=14)
    parser.add_argument("--target-post-ber", type=float, default=1e-9)
    parser.add_argument("--codec-mode", choices=["serial", "batched"], default="batched")
    parser.add_argument("--time-budget-s", type=float, default=1800.0)
    parser.add_argument("--output-dir", type=Path, default=Path("results/raw"))
    args = parser.parse_args()

    _, _, diff_rows, timing_rows = run_paired_sweep(
        snr_values=_snr_values(args.snr_min, args.snr_max, args.snr_step),
        h=args.h,
        min_post_errors=args.min_post_errors,
        max_blocks=args.max_blocks,
        batch_blocks=args.batch_blocks,
        seed=args.seed,
        block_width=args.block_width,
        target_post_ber=args.target_post_ber,
        codec_mode=args.codec_mode,
        time_budget_s=args.time_budget_s,
        output_dir=args.output_dir,
    )
    matched = all(bool(row["matched"]) for row in diff_rows)
    ratio = next(
        (
            float(row["total_point_wall_sec"])
            for row in timing_rows
            if row["backend"] == "ratio_syndrome_lut_over_block_lut"
        ),
        0.0,
    )
    print(f"points={len(diff_rows)} matched={matched} syndrome_lut_over_block_lut={ratio:.6g}")
    print(f"output_dir={args.output_dir}")
    return 0 if matched else 2


if __name__ == "__main__":
    raise SystemExit(main())
