from __future__ import annotations

"""Block-LUT implementation of OFEC's pluggable BCHBackend protocol."""

import sys
from pathlib import Path

import numpy as np

ACP_ROOT = Path(__file__).resolve().parents[2]
OFEC_ROOT = Path(r"D:\PKU\OFEC\project\ofec-0.1.0")
FEC_ROOT = ACP_ROOT / "fec_linear_backend"

for _path in (OFEC_ROOT, FEC_ROOT):
    _path_text = str(_path)
    if _path_text not in sys.path:
        sys.path.insert(0, _path_text)

from linear_kernel import PackedBlockLUTKernel
from ofec.codec._ebch_lut import build_syndrome_lut_tables


class BlockLUTBCHBackend:
    """BCH(255,239) backend that swaps only syndrome/parity evaluation.

    The matrix, packed-bit convention, and bounded-distance decode tables are
    imported from OFEC's official SyndromeLUT backend. This class replaces the
    online GF(2) matrix multiply with PackedBlockLUTKernel while preserving the
    same encode/decode semantics:

    - encode: input shape ``(k,)`` -> BCH codeword shape ``(n_bch,)``
    - decode: input shape ``(n_bch,)`` -> ``(corrected, indicator)``
    - encode_many: input shape ``(batch,k)`` -> ``(batch,n_bch)``
    - decode_many: input shape ``(batch,n_bch)`` -> corrected batch and
      indicators where ``-1`` means failure and ``0/1/2`` is the correction
      weight selected by the official locator table.
    """

    def __init__(self, n_bch: int, k: int, *, block_width: int = 14) -> None:
        self.n_bch = int(n_bch)
        self.k = int(k)
        self._parity_bits = self.n_bch - self.k
        if self._parity_bits > 16:
            raise ValueError("BlockLUTBCHBackend currently supports r <= 16")
        self.block_width = int(block_width)
        self._tables = build_syndrome_lut_tables(self.n_bch, self.k)
        self._syndrome_kernel = PackedBlockLUTKernel(
            self._tables.column_syndrome_bits.astype(np.uint8, copy=False),
            block_width=self.block_width,
            packed_word_bits=16,
        )
        self._parity_kernel = PackedBlockLUTKernel(
            self._tables.column_syndrome_bits[: self.k].astype(np.uint8, copy=False),
            block_width=self.block_width,
            packed_word_bits=16,
        )

    def _as_binary_batch(self, values: np.ndarray, width: int) -> np.ndarray:
        batch = np.asarray(values, dtype=np.int32)
        if batch.ndim != 2 or batch.shape[1] != width:
            raise ValueError(f"Expected shape (batch, {width}), got {batch.shape}")
        if not np.all((batch == 0) | (batch == 1)):
            raise ValueError("Input must be a binary matrix of 0/1")
        return batch

    def encode(self, info: np.ndarray) -> np.ndarray:
        info_bits = np.asarray(info, dtype=np.int32).reshape(1, -1)
        return self.encode_many(info_bits)[0]

    def encode_many(self, info_batch: np.ndarray) -> np.ndarray:
        batch = self._as_binary_batch(info_batch, self.k)
        packed = self._parity_kernel.apply_many_packed(batch.astype(np.uint8, copy=False))
        parity = self._tables.packed_to_bits[packed.astype(np.int32)].astype(np.int32, copy=False)
        return np.concatenate([batch.copy(), parity], axis=1)

    def decode(self, rx_base: np.ndarray) -> tuple[np.ndarray, int]:
        batch = np.asarray(rx_base, dtype=np.int32).reshape(1, -1)
        corrected, indicators = self.decode_many(batch)
        return corrected[0], int(indicators[0])

    def decode_many(self, rx_base_batch: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        batch = self._as_binary_batch(rx_base_batch, self.n_bch)
        corrected = batch.copy()
        syndromes = self._syndrome_kernel.apply_many_packed(
            corrected.astype(np.uint8, copy=False)
        ).astype(np.int32, copy=False)
        counts = self._tables.decode_counts[syndromes].astype(np.int32, copy=False)
        positions = self._tables.decode_positions[syndromes]

        one_error = counts == 1
        if np.any(one_error):
            row_idx = np.nonzero(one_error)[0]
            corrected[row_idx, positions[one_error, 0]] ^= 1

        two_error = counts == 2
        if np.any(two_error):
            row_idx = np.nonzero(two_error)[0]
            corrected[row_idx, positions[two_error, 0]] ^= 1
            corrected[row_idx, positions[two_error, 1]] ^= 1

        indicators = counts.copy()
        indicators[counts < 0] = -1
        return corrected, indicators
