"""Injectable block-LUT BCH backend for the local OFEC simulator."""

from .backend import BlockLUTBCHBackend

__all__ = ["BlockLUTBCHBackend"]
