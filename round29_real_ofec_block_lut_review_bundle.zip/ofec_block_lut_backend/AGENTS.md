This is an external injectable backend package for local OFEC experiments.

Rules:
- Do not modify `D:\PKU\OFEC\project\ofec-0.1.0`.
- Do not copy or replace OFEC encoder/decoder/window/stage logic.
- The only runtime substitution is BCH syndrome/parity linear-map evaluation.
- Reuse the official OFEC syndrome tables by import so matrix and locator
  conventions remain identical to `SyndromeLUTBCHBackend`.
- Reuse `fec_linear_backend` kernels by import; do not reimplement them here.
- All reported BER/timing values must come from generated CSV files.
