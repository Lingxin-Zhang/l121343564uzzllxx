from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ACP_ROOT = Path(__file__).resolve().parents[2]
OFEC_ROOT = Path(r"D:\PKU\OFEC\project\ofec-0.1.0")
FEC_ROOT = ACP_ROOT / "fec_linear_backend"

for path in (OFEC_ROOT, FEC_ROOT):
    path_text = str(path)
    if path_text not in sys.path:
        sys.path.insert(0, path_text)

from ofec.codec._ebch_backends import SyndromeLUTBCHBackend
from ofec.codec.ebch import EBCH256_239

from ofec_block_lut_backend.backend import BlockLUTBCHBackend


def _error_masks(batch_size: int, n: int) -> np.ndarray:
    masks = np.zeros((batch_size, n), dtype=np.int32)
    for row in range(batch_size):
        weight = row % 5
        if weight == 4:
            weight = 7
        for offset in range(weight):
            masks[row, (17 * row + 31 * offset) % n] ^= 1
    return masks


def test_bch_block_lut_backend_matches_official_syndrome_lut_encode_decode_many():
    rng = np.random.default_rng(20260829)
    n_bch = 255
    k = 239
    batch_size = 80
    reference = SyndromeLUTBCHBackend(n_bch, k)
    candidate = BlockLUTBCHBackend(n_bch, k, block_width=14)

    info = rng.integers(0, 2, size=(batch_size, k), dtype=np.int32)
    reference_codewords = reference.encode_many(info)
    candidate_codewords = candidate.encode_many(info)
    np.testing.assert_array_equal(candidate_codewords, reference_codewords)

    received = reference_codewords ^ _error_masks(batch_size, n_bch)
    reference_corrected, reference_indicators = reference.decode_many(received)
    candidate_corrected, candidate_indicators = candidate.decode_many(received)

    np.testing.assert_array_equal(candidate_corrected, reference_corrected)
    np.testing.assert_array_equal(candidate_indicators, reference_indicators)


def test_ebch_wrapper_matches_with_block_lut_backend_injected():
    rng = np.random.default_rng(20260830)
    batch_size = 64
    reference_backend = SyndromeLUTBCHBackend(255, 239)
    candidate_backend = BlockLUTBCHBackend(255, 239, block_width=14)
    reference = EBCH256_239(t=2, backend=reference_backend)
    candidate = EBCH256_239(t=2, backend=candidate_backend)

    info = rng.integers(0, 2, size=(batch_size, reference.k), dtype=np.int32)
    reference_codewords = reference.encode_many(info)
    candidate_codewords = candidate.encode_many(info)
    np.testing.assert_array_equal(candidate_codewords, reference_codewords)

    received = reference_codewords.copy()
    received[:, : reference.n_bch] ^= _error_masks(batch_size, reference.n_bch)
    received[::6, reference.n_bch] ^= 1

    reference_results = reference.decode_many(received)
    candidate_results = candidate.decode_many(received)

    for ref, cand in zip(reference_results, candidate_results):
        np.testing.assert_array_equal(cand.word, ref.word)
        np.testing.assert_array_equal(cand.error_location, ref.error_location)
        assert cand.status == ref.status
        assert cand.bch_error_indicator == ref.bch_error_indicator
        assert cand.parity_flip == ref.parity_flip
        assert cand.total_error_estimate == ref.total_error_estimate
